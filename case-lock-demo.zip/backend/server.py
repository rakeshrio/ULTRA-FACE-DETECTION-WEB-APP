from flask import Flask, request, jsonify
from flask_cors import CORS
import datetime

app = Flask(__name__)
CORS(app)

locks = {}  # { case_id: { "locked_by": user, "locked_until": datetime } }

@app.route("/cases/<case_id>", methods=["GET"])
def get_case(case_id):
    user = request.args.get("user")
    now = datetime.datetime.utcnow()

    # If case not locked or expired -> lock for this user
    if case_id not in locks or locks[case_id]["locked_until"] < now:
        locks[case_id] = {
            "locked_by": user,
            "locked_until": now + datetime.timedelta(seconds=60)
        }

    return jsonify({
        "case_id": case_id,
        "locked_by": locks[case_id]["locked_by"],
        "locked_until": locks[case_id]["locked_until"].isoformat() + "Z"
    })

@app.route("/cases/<case_id>/release", methods=["POST"])
def release_case(case_id):
    data = request.get_json()
    user = data.get("user")

    if case_id in locks and locks[case_id]["locked_by"] == user:
        del locks[case_id]
        return jsonify({"status": "released"})
    return jsonify({"status": "not_locked_or_not_owner"})

if __name__ == "__main__":
    app.run(debug=True)
