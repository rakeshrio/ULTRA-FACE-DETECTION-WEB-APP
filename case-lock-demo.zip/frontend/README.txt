# Vue Frontend (placeholder)

Run these commands manually:

vue create case-lock-frontend
cd case-lock-frontend
npm install axios

# Add CaseDetails.vue and router config as provided in the explanation.
