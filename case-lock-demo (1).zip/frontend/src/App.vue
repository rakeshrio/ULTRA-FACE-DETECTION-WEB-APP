<template>
  <div class="container">
    <h1>Case Lock Demo</h1>
    <div v-for="caseItem in cases" :key="caseItem.id" class="case-card">
      <h3>{{ caseItem.title }}</h3>
      
      <div v-if="caseItem.locked">
        <p>🔒 Locked by {{ caseItem.locked_by }}</p>
        <p v-if="caseItem.seconds_left">⏳ {{ caseItem.seconds_left }}s left</p>
      </div>
      
      <div v-else>
        <button @click="lockCase(caseItem.id)">Open & Lock</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      cases: [],
      user: "UserA" // 🔧 Change per tab to simulate multiple users
    };
  },
  methods: {
    async fetchCases() {
      const res = await axios.get("http://127.0.0.1:5000/cases");
      this.cases = res.data;
    },
    async lockCase(caseId) {
      await axios.post(`http://127.0.0.1:5000/lock/${caseId}/${this.user}`);
      this.fetchCases();
    },
    async unlockCase(caseId) {
      await axios.post(`http://127.0.0.1:5000/unlock/${caseId}/${this.user}`);
      this.fetchCases();
    }
  },
  mounted() {
    this.fetchCases();
    setInterval(this.fetchCases, 1000); // 🔄 auto-refresh every 1s
  }
};
</script>

<style>
.container {
  max-width: 600px;
  margin: 20px auto;
  font-family: Arial, sans-serif;
}
.case-card {
  border: 1px solid #ccc;
  padding: 12px;
  margin-bottom: 12px;
  border-radius: 6px;
}
button {
  padding: 6px 12px;
  background: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
button:hover {
  background: #36956d;
}
</style>
