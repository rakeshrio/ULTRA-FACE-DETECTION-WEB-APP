from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import time

app = FastAPI()

# Allow Vue frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dummy cases
cases = [
    {"id": "case1", "title": "Case One"},
    {"id": "case2", "title": "Case Two"},
    {"id": "case3", "title": "Case Three"},
]

locks = {}  # {case_id: {"user": "UserA", "timestamp": 1234}}
LOCK_DURATION = 60


def cleanup_expired_locks():
    now = time.time()
    expired = [
        cid for cid, data in locks.items()
        if now - data["timestamp"] > LOCK_DURATION
    ]
    for cid in expired:
        del locks[cid]


@app.get("/cases")
def get_cases():
    cleanup_expired_locks()
    result = []
    for c in cases:
        locked = c["id"] in locks
        result.append({
            "id": c["id"],
            "title": c["title"],
            "locked": locked,
            "locked_by": locks[c["id"]]["user"] if locked else None,
            "seconds_left": LOCK_DURATION - int(time.time() - locks[c["id"]]["timestamp"]) if locked else None
        })
    return result


@app.post("/lock/{case_id}/{user}")
def lock_case(case_id: str, user: str):
    cleanup_expired_locks()
    if case_id in locks:
        return {
            "success": False,
            "locked_by": locks[case_id]["user"],
            "seconds_left": LOCK_DURATION - int(time.time() - locks[case_id]["timestamp"])
        }
    locks[case_id] = {"user": user, "timestamp": time.time()}
    return {"success": True, "locked_by": user, "seconds_left": LOCK_DURATION}


@app.post("/unlock/{case_id}/{user}")
def unlock_case(case_id: str, user: str):
    if case_id in locks and locks[case_id]["user"] == user:
        del locks[case_id]
    return {"success": True}
